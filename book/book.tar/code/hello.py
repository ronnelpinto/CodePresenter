print "hello"
if True:
		print "hi"