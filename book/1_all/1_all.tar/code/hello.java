class test {
private int abc;
public static void main(String[] args) { System.out.println("From file"); }
}